from django import forms
from .models import Task

class TaskForm(forms.ModelForm):
    class Meta:
        model = Task
        fields = ['title', 'description', 'completed', 'data']  # Inclua o campo data
        widgets = {
            'data': forms.DateInput(attrs={'type': 'date'}),  # Isso cria o campo de data com o calendário
        }
