from django.shortcuts import render, redirect, get_object_or_404
from django.http import JsonResponse
from .models import Task
from .forms import TaskForm
from django.views.decorators.csrf import csrf_exempt

def task_list(request):
    tasks = Task.objects.all()  # Busca todas as tarefas
    form = TaskForm()

    # Verifica se o formulário foi enviado (POST)
    if request.method == "POST":
        form = TaskForm(request.POST)
        if form.is_valid():
            form.save()  # Salva a nova tarefa
            return redirect('task_list')  # Recarrega a página após adicionar

    # Exibe as tarefas e o formulário
    return render(request, 'tasks/task_list.html', {'tasks': tasks, 'form': form})

def task_create(request):
    if request.method == 'POST':
        form = TaskForm(request.POST)
        if form.is_valid():
            task = form.save(commit=False)  # Cria uma instância, mas não salva ainda
            task.save()  # Salva no banco de dados
            return redirect('task_list')
    else:
        form = TaskForm()  # Cria um novo formulário vazio
    return render(request, 'tasks/task_form.html', {'form': form})

@csrf_exempt  # Permite o envio de requisição sem token CSRF para facilitar a chamada AJAX
def update_task_status(request, task_id):
    if request.method == 'POST':
        try:
            task = Task.objects.get(id=task_id)
            completed = request.POST.get('completed') == 'true'  # Verifica se a tarefa foi marcada como completada
            task.completed = completed
            task.save()
            return JsonResponse({'success': True})
        except Task.DoesNotExist:
            return JsonResponse({'success': False, 'error': 'Tarefa não encontrada'})
    return JsonResponse({'success': False, 'error': 'Método não permitido'})

# Função para excluir uma tarefa
def task_delete(request, pk):
    try:
        task = get_object_or_404(Task, pk=pk)  # Obtém a tarefa pelo id (pk)
        task.delete()  # Exclui a tarefa
        return redirect('task_list')  # Redireciona de volta para a lista de tarefas
    except Task.DoesNotExist:
        return JsonResponse({'success': False, 'error': 'Tarefa não encontrada'})
